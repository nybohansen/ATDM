autoreconf --force --install -B src/m4
